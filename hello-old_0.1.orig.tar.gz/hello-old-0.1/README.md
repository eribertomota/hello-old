hello-old
============

A old style hello

Hello Old is a program that says Hello to all users. This program is useful to learn
the basics about C language. All people need to know the very nice effect caused by
hello-old.

Hello Old can be used to demonstrate the total power of the computers.





------- IGNORE WHEN PACKAGING -------------------

PS: this code can have some problems and was developed to help in Debian
    packaging lessons. Please, don't open bugs against this project.
